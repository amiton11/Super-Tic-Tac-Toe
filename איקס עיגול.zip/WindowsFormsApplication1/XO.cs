﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XO
{
    public partial class  XO : Form
    {
        public int counter;
        public string PlayerX, PlayerO;
        public int ComputerTotalScore, PlayerTotalScore;
        public int Y, X, ToWin, StepsForwad, NewY, NewX;
        public Button[,] btnArr;
        public int YFrom, YTo, XFrom, XTo;
        public int[,] ShuraArr, AmudaArr ,MainAlachsonArr, SecondAlachsonArr;
        public bool PlayerXTurn;
        public XO()
        {
            InitializeComponent();
        }
        /**
         הפונקציה מקבלת את מפת הניקוד על פי רצפים הנוכחית של הלוח ומחזירה את הניקוד הכולל של המחשב פחות הניקוד של השחקן
         קלט:
            ,ארבע מערכים דו מימדיים, 
            ,אחד מתאר את הניקוד של הרצפים שקשורים לניצחון בשורה 
            ,אחד מתאר את הניקוד של הרצפים שקשורים בטור
            (אחד את הרצפים שקשורים לאלכוסונים שמגיעים מימין למעלה לשמאל למטה(אלכסונים משניים
            .(והאחרון את הרצפים שקשורים לאלכסונים שמגיעים משמאל למעלה לימין למטה(אלכסונים ראשיים
         פלט:
            .מספר שלם שמייצג את הניקוד הכולל של המחשב על פי המערכים שהפונקציה קיבלה כקלט, פחות הניקוד הכולל של השחקן
         */
        private int ScoreSystem(int[,] MainAlachson, int[,] SecondAlachson, int[,] Shura, int[,] Amuda)
        {
            ComputerTotalScore = 0; 
            PlayerTotalScore = 0;
            for (int i = 0; i < NewY; i++)
            {
                for (int j = 0; j < X; j++)
                {
                    if (Shura[i, j] % 1000 == 0 && Shura[i, j] > 0)
                        ComputerTotalScore += Shura[i, j] / 1000;
                    if (Shura[i, j] % 1000 > 0 && Shura[i, j] / 1000 == 0)
                        PlayerTotalScore += Shura[i, j];
                }
            }
            for (int i = 0; i < Y; i++)
            {
                for (int j = 0; j < NewX; j++)
                {
                    if (Amuda[i, j] % 1000 == 0 && Amuda[i, j] > 0)
                        ComputerTotalScore += Amuda[i, j] / 1000;
                    if (Amuda[i, j] % 1000 > 0 && Amuda[i, j] / 1000 == 0)
                        PlayerTotalScore += Amuda[i, j];
                }
            }
            for (int i = 0; i < NewY; i++)
            {
                for (int j = 0; j < NewX; j++)
                {
                    if (MainAlachson[i, j] % 1000 == 0 && MainAlachson[i, j] > 0)
                        ComputerTotalScore += MainAlachson[i, j] / 1000;
                    if (MainAlachson[i, j] % 1000 > 0 && MainAlachson[i, j] / 1000 == 0)
                        PlayerTotalScore += MainAlachson[i, j];
                    if (SecondAlachson[i, j] % 1000 == 0 && SecondAlachson[i, j] > 0)
                        ComputerTotalScore += SecondAlachson[i, j] / 1000;
                    if (SecondAlachson[i, j] % 1000 > 0 && SecondAlachson[i, j] / 1000 == 0)
                        PlayerTotalScore += SecondAlachson[i, j];
                }
            }
            return (ComputerTotalScore - PlayerTotalScore);
        }
        /**
         פונקציה רקורסיבית, אחראית על דימוי המהלכים של המחשב ושל השחקן לסירוגין 
         ,שווה ל0 StepsLeft2 על ידי קריאה לעצמה עד שמגיעה למצב בו 
         .שתחזיר את הניקוד של הלוח במצב זה ScoreSystemכלומר שהיא לא אמורה לבדוק עוד צעדים קדימה, ואז היא קוראת ל
         .כל פעם היא בודקת אם מדובר בתור מדומה של המחשב או של השחקן
         (FirstComBestMoveבמידה ומדובר בתור מדומה של השחקן היא מחזירה לפונקציה שקראה לה (לרוב לעצמה אך גם בסוף ל
         את הניקוד של המהלך עם הניקוד הקטן ביותר. במידה ומדובר בתור מדומה של המחשב
         .היא תחזיר את הניקוד של המהלך עם הניקוד הכי גבוה
         קלט:
            ('מערך כפתורים שבעצם מייצג את הלוח כולל כל נתוניו הישירים(טקסט וכו
            מספר שמתאר כמה צעדים נשאר לפונקציה לעשות, כל פעם יורד ב1
            משתנה בוליאני שקובע אם תור המחשב או השחקן
            (מספר שמתאר את הניקוד של המהלך עם הניקוד הכי גבוה בינתיים בתור הקודם(כלומר בתור שקרא לתור מדומה זה
            מספר כמו הקודם רק שמתאר מה היה הניקוד של המהלך עם הניקוד הכי נמוך
         פלט:
            מספר שמתאר את הניקוד הכי נמוך ואו הכי גבוה שהיה בתור האחרון שנבדק על ידי פונקציה זו
         */
        private int ComBestMove(Button[,] ButtonArr2, int StepsLeft2, bool ComTurn, int BiggestScore, int LowestScore)
        {
            if (StepsLeft2 <= 0)
            {
                return ScoreSystem(MainAlachsonArr, SecondAlachsonArr ,ShuraArr, AmudaArr);
            }
            int Score;
            if (ComTurn == true)
            {
                for (int i = 0; i < Y; i++)
                {
                    for (int j = 0; j < X; j++)
                    {
                        if (ButtonArr2[i, j].Text != "X" && ButtonArr2[i, j].Text != "O")
                        {
                            ButtonArr2[i, j].Text = "O";
                            YFrom = i - ToWin + 1;
                            YTo = i;
                            if (YFrom < 0)
                                YFrom = 0;
                            if (YTo > NewY - 1)
                                YTo = NewY - 1;
                            XFrom = j - ToWin + 1;
                            XTo = j;
                            if (XFrom < 0)
                                XFrom = 0;
                            if (XTo > NewX - 1)
                                XTo = NewX - 1;
                            for (int g = YFrom; g <= YTo; g++)
                                ShuraArr[g, j] += 1000;
                            for (int g = XFrom; g <= XTo; g++)
                                AmudaArr[i, g] += 1000;
                            if (i > j)
                            {
                                if (j + 1 < ToWin)
                                    YFrom = i - j;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (i - j + ToWin <= Y)
                                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                        MainAlachsonArr[g, h] += 1000;
                            }
                            else
                            {
                                if (i + 1 < ToWin)
                                    XFrom = j - i;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (j - i + ToWin <= X)
                                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                        MainAlachsonArr[g, h] += 1000;
                            }
                            if (i + j < Y)
                            {
                                if (i + j - ToWin + 1 >= 0)
                                {
                                    YFrom = i + ToWin - 1;
                                    XFrom = j - ToWin + 1;
                                    YTo = i;
                                    XTo = j;
                                    while (YFrom >= Y || XFrom < 0)
                                    {
                                        YFrom--;
                                        XFrom++;
                                    }
                                    while (YTo < Y - NewY || XTo >= NewX)
                                    {
                                        YTo++;
                                        XTo--;
                                    }
                                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                        SecondAlachsonArr[g - Y + NewY, h] += 1000;
                                }
                            }
                            else
                            {
                                if (i + j - Y + ToWin <= Y)
                                {
                                    YFrom = i + ToWin - 1;
                                    XFrom = j - ToWin + 1;
                                    YTo = i;
                                    XTo = j;
                                    while (YFrom >= Y || XFrom < 0)
                                    {
                                        YFrom--;
                                        XFrom++;
                                    }
                                    while (YTo < Y - NewY || XTo >= NewX)
                                    {
                                        YTo++;
                                        XTo--;
                                    }
                                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                        SecondAlachsonArr[g - Y + NewY, h] += 1000;
                                }
                            }
                            if (Win(i, j, false) == "Win")
                            {
                                Score = int.MaxValue;
                                ButtonArr2[i, j].Text = (i * 1000 + j).ToString();
                                YFrom = i - ToWin + 1;
                                YTo = i;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (YTo > NewY - 1)
                                    YTo = NewY - 1;
                                XFrom = j - ToWin + 1;
                                XTo = j;
                                if (XFrom < 0)
                                    XFrom = 0;
                                if (XTo > NewX - 1)
                                    XTo = NewX - 1;
                                for (int g = YFrom; g <= YTo; g++)
                                    ShuraArr[g, j] -= 1000;
                                for (int g = XFrom; g <= XTo; g++)
                                    AmudaArr[i, g] -= 1000;
                                if (i > j)
                                {
                                    if (j + 1 < ToWin)
                                        YFrom = i - j;
                                    if (YFrom < 0)
                                        YFrom = 0;
                                    if (i - j + ToWin <= Y)
                                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                            MainAlachsonArr[g, h] -= 1000;
                                }
                                else
                                {
                                    if (i + 1 < ToWin)
                                        XFrom = j - i;
                                    if (YFrom < 0)
                                        YFrom = 0;
                                    if (j - i + ToWin <= X)
                                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                            MainAlachsonArr[g, h] -= 1000;
                                }
                                if (i + j < Y)
                                {
                                    if (i + j - ToWin + 1 >= 0)
                                    {
                                        YFrom = i + ToWin - 1;
                                        XFrom = j - ToWin + 1;
                                        YTo = i;
                                        XTo = j;
                                        while (YFrom >= Y || XFrom < 0)
                                        {
                                            YFrom--;
                                            XFrom++;
                                        }
                                        while (YTo < Y - NewY || XTo >= NewX)
                                        {
                                            YTo++;
                                            XTo--;
                                        }
                                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                            SecondAlachsonArr[g - Y + NewY, h] -= 1000;
                                    }
                                }
                                else
                                {
                                    if (i + j - Y + ToWin <= Y)
                                    {
                                        YFrom = i + ToWin - 1;
                                        XFrom = j - ToWin + 1;
                                        YTo = i;
                                        XTo = j;
                                        while (YFrom >= Y || XFrom < 0)
                                        {
                                            YFrom--;
                                            XFrom++;
                                        }
                                        while (YTo < Y - NewY || XTo >= NewX)
                                        {
                                            YTo++;
                                            XTo--;
                                        }
                                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                            SecondAlachsonArr[g - Y + NewY, h] -= 1000;
                                    }
                                }
                                return Score;
                            }
                            else
                            {
                                Score = ComBestMove(ButtonArr2, StepsLeft2 - 1, !ComTurn, BiggestScore, LowestScore);
                                ButtonArr2[i, j].Text = (i * 1000 + j).ToString();
                                YFrom = i - ToWin + 1;
                                YTo = i;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (YTo > NewY - 1)
                                    YTo = NewY - 1;
                                XFrom = j - ToWin + 1;
                                XTo = j;
                                if (XFrom < 0)
                                    XFrom = 0;
                                if (XTo > NewX - 1)
                                    XTo = NewX - 1;
                                for (int g = YFrom; g <= YTo; g++)
                                    ShuraArr[g, j] -= 1000;
                                for (int g = XFrom; g <= XTo; g++)
                                    AmudaArr[i, g] -= 1000;
                                if (i > j)
                                {
                                    if (j + 1 < ToWin)
                                        YFrom = i - j;
                                    if (YFrom < 0)
                                        YFrom = 0;
                                    if (i - j + ToWin <= Y)
                                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                            MainAlachsonArr[g, h] -= 1000;
                                }
                                else
                                {
                                    if (i + 1 < ToWin)
                                        XFrom = j - i;
                                    if (YFrom < 0)
                                        YFrom = 0;
                                    if (j - i + ToWin <= X)
                                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                            MainAlachsonArr[g, h] -= 1000;
                                }
                                if (i + j < Y)
                                {
                                    if (i + j - ToWin + 1 >= 0)
                                    {
                                        YFrom = i + ToWin - 1;
                                        XFrom = j - ToWin + 1;
                                        YTo = i;
                                        XTo = j;
                                        while (YFrom >= Y || XFrom < 0)
                                        {
                                            YFrom--;
                                            XFrom++;
                                        }
                                        while (YTo < Y - NewY || XTo >= NewX)
                                        {
                                            YTo++;
                                            XTo--;
                                        }
                                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                            SecondAlachsonArr[g - Y + NewY, h] -= 1000;
                                    }
                                }
                                else
                                {
                                    if (i + j - Y + ToWin <= Y)
                                    {
                                        YFrom = i + ToWin - 1;
                                        XFrom = j - ToWin + 1;
                                        YTo = i;
                                        XTo = j;
                                        while (YFrom >= Y || XFrom < 0)
                                        {
                                            YFrom--;
                                            XFrom++;
                                        }
                                        while (YTo < Y - NewY || XTo >= NewX)
                                        {
                                            YTo++;
                                            XTo--;
                                        }
                                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                            SecondAlachsonArr[g - Y + NewY, h] -= 1000;
                                    }
                                }
                                if (Score > LowestScore)
                                {
                                    return Score;
                                }
                                if (Score > BiggestScore)
                                {
                                    BiggestScore = Score;
                                }
                            }
                        }
                    }
                }
                return BiggestScore;
            }
            else
            {
                for (int i = 0; i < Y; i++)
                {
                    for (int j = 0; j < X; j++)
                    {
                        if (ButtonArr2[i, j].Text != "X" && ButtonArr2[i, j].Text != "O")
                        {
                            ButtonArr2[i, j].Text = "X";
                            YFrom = i - ToWin + 1;
                            YTo = i;
                            if (YFrom < 0)
                                YFrom = 0;
                            if (YTo > NewY - 1)
                                YTo = NewY - 1;
                            XFrom = j - ToWin + 1;
                            XTo = j;
                            if (XFrom < 0)
                                XFrom = 0;
                            if (XTo > NewX - 1)
                                XTo = NewX - 1;
                            for (int g = YFrom; g <= YTo; g++)
                                ShuraArr[g, j]++;
                            for (int g = XFrom; g <= XTo; g++)
                                AmudaArr[i, g]++;
                            if (i > j)
                            {
                                if (j + 1 < ToWin)
                                    YFrom = i - j;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (i - j + ToWin <= Y)
                                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                        MainAlachsonArr[g, h]++;
                            }
                            else
                            {
                                if (i + 1 < ToWin)
                                    XFrom = j - i;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (j - i + ToWin <= X)
                                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                        MainAlachsonArr[g, h]++;
                            }
                            if (i + j < Y)
                            {
                                if (i + j - ToWin + 1 >= 0)
                                {
                                    YFrom = i + ToWin - 1;
                                    XFrom = j - ToWin + 1;
                                    YTo = i;
                                    XTo = j;
                                    while (YFrom >= Y || XFrom < 0)
                                    {
                                        YFrom--;
                                        XFrom++;
                                    }
                                    while (YTo < Y - NewY || XTo >= NewX)
                                    {
                                        YTo++;
                                        XTo--;
                                    }
                                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                        SecondAlachsonArr[g - Y + NewY, h]++;
                                }
                            }
                            else
                            {
                                if (i + j - Y + ToWin <= Y)
                                {
                                    YFrom = i + ToWin - 1;
                                    XFrom = j - ToWin + 1;
                                    YTo = i;
                                    XTo = j;
                                    while (YFrom >= Y || XFrom < 0)
                                    {
                                        YFrom--;
                                        XFrom++;
                                    }
                                    while (YTo < Y - NewY || XTo >= NewX)
                                    {
                                        YTo++;
                                        XTo--;
                                    }
                                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                        SecondAlachsonArr[g - Y + NewY, h]++;
                                }
                            }
                            if (Win(i, j, true) == "Win")
                            {
                                LowestScore = int.MinValue;
                                ButtonArr2[i, j].Text = (i * 1000 + j).ToString();
                                YFrom = i - ToWin + 1;
                                YTo = i;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (YTo > NewY - 1)
                                    YTo = NewY - 1;
                                XFrom = j - ToWin + 1;
                                XTo = j;
                                if (XFrom < 0)
                                    XFrom = 0;
                                if (XTo > NewX - 1)
                                    XTo = NewX - 1;
                                for (int g = YFrom; g <= YTo; g++)
                                    ShuraArr[g, j]--;
                                for (int g = XFrom; g <= XTo; g++)
                                    AmudaArr[i, g]--;
                                if (i > j)
                                {
                                    if (j + 1 < ToWin)
                                        YFrom = i - j;
                                    if (YFrom < 0)
                                        YFrom = 0;
                                    if (i - j + ToWin <= Y)
                                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                            MainAlachsonArr[g, h]--;
                                }
                                else
                                {
                                    if (i + 1 < ToWin)
                                        XFrom = j - i;
                                    if (YFrom < 0)
                                        YFrom = 0;
                                    if (j - i + ToWin <= X)
                                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                            MainAlachsonArr[g, h]--;
                                }
                                if (i + j < Y)
                                {
                                    if (i + j - ToWin + 1 >= 0)
                                    {
                                        YFrom = i + ToWin - 1;
                                        XFrom = j - ToWin + 1;
                                        YTo = i;
                                        XTo = j;
                                        while (YFrom >= Y || XFrom < 0)
                                        {
                                            YFrom--;
                                            XFrom++;
                                        }
                                        while (YTo < Y - NewY || XTo >= NewX)
                                        {
                                            YTo++;
                                            XTo--;
                                        }
                                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                            SecondAlachsonArr[g - Y + NewY, h]--;
                                    }
                                }
                                else
                                {
                                    if (i + j - Y + ToWin <= Y)
                                    {
                                        YFrom = i + ToWin - 1;
                                        XFrom = j - ToWin + 1;
                                        YTo = i;
                                        XTo = j;
                                        while (YFrom >= Y || XFrom < 0)
                                        {
                                            YFrom--;
                                            XFrom++;
                                        }
                                        while (YTo < Y - NewY || XTo >= NewX)
                                        {
                                            YTo++;
                                            XTo--;
                                        }
                                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                            SecondAlachsonArr[g - Y + NewY, h]--;
                                    }
                                }
                                return LowestScore;
                            }
                            else
                            {
                                Score = ComBestMove(ButtonArr2, StepsLeft2 - 1, !ComTurn, BiggestScore, LowestScore);
                                ButtonArr2[i, j].Text = (i * 1000 + j).ToString();
                                YFrom = i - ToWin + 1;
                                YTo = i;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (YTo > NewY - 1)
                                    YTo = NewY - 1;
                                XFrom = j - ToWin + 1;
                                XTo = j;
                                if (XFrom < 0)
                                    XFrom = 0;
                                if (XTo > NewX - 1)
                                    XTo = NewX - 1;
                                for (int g = YFrom; g <= YTo; g++)
                                    ShuraArr[g, j]--;
                                for (int g = XFrom; g <= XTo; g++)
                                    AmudaArr[i, g]--;
                                if (i > j)
                                {
                                    if (j + 1 < ToWin)
                                        YFrom = i - j;
                                    if (YFrom < 0)
                                        YFrom = 0;
                                    if (i - j + ToWin <= Y)
                                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                            MainAlachsonArr[g, h]--;
                                }
                                else
                                {
                                    if (i + 1 < ToWin)
                                        XFrom = j - i;
                                    if (YFrom < 0)
                                        YFrom = 0;
                                    if (j - i + ToWin <= X)
                                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                            MainAlachsonArr[g, h]--;
                                }
                                if (i + j < Y)
                                {
                                    if (i + j - ToWin + 1 >= 0)
                                    {
                                        YFrom = i + ToWin - 1;
                                        XFrom = j - ToWin + 1;
                                        YTo = i;
                                        XTo = j;
                                        while (YFrom >= Y || XFrom < 0)
                                        {
                                            YFrom--;
                                            XFrom++;
                                        }
                                        while (YTo < Y - NewY || XTo >= NewX)
                                        {
                                            YTo++;
                                            XTo--;
                                        }
                                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                            SecondAlachsonArr[g - Y + NewY, h]--;
                                    }
                                }
                                else
                                {
                                    if (i + j - Y + ToWin <= Y)
                                    {
                                        YFrom = i + ToWin - 1;
                                        XFrom = j - ToWin + 1;
                                        YTo = i;
                                        XTo = j;
                                        while (YFrom >= Y || XFrom < 0)
                                        {
                                            YFrom--;
                                            XFrom++;
                                        }
                                        while (YTo < Y - NewY || XTo >= NewX)
                                        {
                                            YTo++;
                                            XTo--;
                                        }
                                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                            SecondAlachsonArr[g - Y + NewY, h]--;
                                    }
                                }
                                if (Score < BiggestScore)
                                {
                                    return Score;
                                }
                                if (Score < LowestScore)
                                {
                                    LowestScore = Score;
                                }
                            }
                        }
                    }
                }
                return LowestScore;
            }
        }
        /**
         .ComBestMove פונקציה זו אחראית על התור המדומה הראשון שקורה לפני 
         .ובוחרת לשחק את המהלך שקיבל את הניקוד הגבוה ביותר ComBestMove פונקציה זו בעצם קוראת לפונקציה 
         ,לאחר שהיא בוחרת במהלך עם הניקוד הגבוה ביותר היא משחקת אותו באמת על הלוח שנמצא בחלון התוכנית
         .ובודקת האם היה ניצחון
         קלט:
            מערך כפתורים שמסמל את המצב הנוכחי של הלוח
            מספר שמתאר כמה צעדים קדימה צריכה הפונקציה לחשוב
         פלט:
            אין
         */
        private void FirstComBestMove(Button[,] ButtonArr, int StepsLeft)
        {
            int BiggestScore = int.MinValue, BestShura = 0, BestAmuda = 0, LowestScore = int.MaxValue, Score;
            for (int i = 0; i < Y; i++)
            {
                for (int j = 0; j < X; j++)
                {
                    if (ButtonArr[i, j].Text != "X" && ButtonArr[i, j].Text != "O")
                    {
                        ButtonArr[i, j].Text = "O";
                        YFrom = i - ToWin + 1;
                        YTo = i;
                        if (YFrom < 0)
                            YFrom = 0;
                        if (YTo > NewY - 1)
                            YTo = NewY - 1;
                        XFrom = j - ToWin + 1;
                        XTo = j;
                        if (XFrom < 0)
                            XFrom = 0;
                        if (XTo > NewX - 1)
                            XTo = NewX - 1;
                        for (int g = YFrom; g <= YTo; g++)
                            ShuraArr[g, j] += 1000;
                        for (int g = XFrom; g <= XTo; g++)
                            AmudaArr[i, g] += 1000;
                        if (i > j)
                        {
                            if (j + 1 < ToWin)
                                YFrom = i - j;
                            if (YFrom < 0)
                                YFrom = 0;
                            if (i - j + ToWin <= Y)
                                for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                    MainAlachsonArr[g, h] += 1000;
                        }
                        else
                        {
                            if (i + 1 < ToWin)
                                XFrom = j - i;
                            if (YFrom < 0)
                                YFrom = 0;
                            if (j - i + ToWin <= X)
                                for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                    MainAlachsonArr[g, h] += 1000;
                        }
                        if (i + j < Y)
                        {
                            if (i + j - ToWin + 1 >= 0)
                            {
                                YFrom = i + ToWin - 1;
                                XFrom = j - ToWin + 1;
                                YTo = i;
                                XTo = j;
                                while (YFrom >= Y || XFrom < 0)
                                {
                                    YFrom--;
                                    XFrom++;
                                }
                                while (YTo < Y - NewY || XTo >= NewX)
                                {
                                    YTo++;
                                    XTo--;
                                }
                                for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                    SecondAlachsonArr[g - Y + NewY, h] += 1000;
                            }
                        }
                        else
                        {
                            if (i + j - Y + ToWin <= Y)
                            {
                                YFrom = i + ToWin - 1;
                                XFrom = j - ToWin + 1;
                                YTo = i;
                                XTo = j;
                                while (YFrom >= Y || XFrom < 0)
                                {
                                    YFrom--;
                                    XFrom++;
                                }
                                while (YTo < Y - NewY || XTo >= NewX)
                                {
                                    YTo++;
                                    XTo--;
                                }
                                for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                    SecondAlachsonArr[g - Y + NewY, h] += 1000;
                            }
                        }
                        if (Win(i, j, false) == "Win")
                        {
                            BestShura = i;
                            BestAmuda = j;
                            ButtonArr[i, j].Text = (i * 1000 + j).ToString();
                            YFrom = i - ToWin + 1;
                            YTo = i;
                            if (YFrom < 0)
                                YFrom = 0;
                            if (YTo > NewY - 1)
                                YTo = NewY - 1;
                            XFrom = j - ToWin + 1;
                            XTo = j;
                            if (XFrom < 0)
                                XFrom = 0;
                            if (XTo > NewX - 1)
                                XTo = NewX - 1;
                            for (int g = YFrom; g <= YTo; g++)
                                ShuraArr[g, j] -= 1000;
                            for (int g = XFrom; g <= XTo; g++)
                                AmudaArr[i, g] -= 1000;
                            if (i > j)
                            {
                                if (j + 1 < ToWin)
                                    YFrom = i - j;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (i - j + ToWin <= Y)
                                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                        MainAlachsonArr[g, h] -= 1000;
                            }
                            else
                            {
                                if (i + 1 < ToWin)
                                    XFrom = j - i;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (j - i + ToWin <= X)
                                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                        MainAlachsonArr[g, h] -= 1000;
                            }
                            if (i + j < Y)
                            {
                                if (i + j - ToWin + 1 >= 0)
                                {
                                    YFrom = i + ToWin - 1;
                                    XFrom = j - ToWin + 1;
                                    YTo = i;
                                    XTo = j;
                                    while (YFrom >= Y || XFrom < 0)
                                    {
                                        YFrom--;
                                        XFrom++;
                                    }
                                    while (YTo < Y - NewY || XTo >= NewX)
                                    {
                                        YTo++;
                                        XTo--;
                                    }
                                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                        SecondAlachsonArr[g - Y + NewY, h] -= 1000;
                                }
                            }
                            else
                            {
                                if (i + j - Y + ToWin <= Y)
                                {
                                    YFrom = i + ToWin - 1;
                                    XFrom = j - ToWin + 1;
                                    YTo = i;
                                    XTo = j;
                                    while (YFrom >= Y || XFrom < 0)
                                    {
                                        YFrom--;
                                        XFrom++;
                                    }
                                    while (YTo < Y - NewY || XTo >= NewX)
                                    {
                                        YTo++;
                                        XTo--;
                                    }
                                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                        SecondAlachsonArr[g - Y + NewY, h] -= 1000;
                                }
                            }
                            i = Y;
                            j = X;
                        }
                        else
                        {
                            Score = ComBestMove(ButtonArr, StepsLeft - 1, false, BiggestScore, LowestScore);
                            if (Score > BiggestScore)
                            {
                                BiggestScore = Score;
                                BestShura = i;
                                BestAmuda = j;
                            }
                            ButtonArr[i, j].Text = (i * 1000 + j).ToString();
                            YFrom = i - ToWin + 1;
                            YTo = i;
                            if (YFrom < 0)
                                YFrom = 0;
                            if (YTo > NewY - 1)
                                YTo = NewY - 1;
                            XFrom = j - ToWin + 1;
                            XTo = j;
                            if (XFrom < 0)
                                XFrom = 0;
                            if (XTo > NewX - 1)
                                XTo = NewX - 1;
                            for (int g = YFrom; g <= YTo; g++)
                                ShuraArr[g, j] -= 1000;
                            for (int g = XFrom; g <= XTo; g++)
                                AmudaArr[i, g] -= 1000;
                            if (i > j)
                            {
                                if (j + 1 < ToWin)
                                    YFrom = i - j;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (i - j + ToWin <= Y)
                                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                        MainAlachsonArr[g, h] -= 1000;
                            }
                            else
                            {
                                if (i + 1 < ToWin)
                                    XFrom = j - i;
                                if (YFrom < 0)
                                    YFrom = 0;
                                if (j - i + ToWin <= X)
                                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                        MainAlachsonArr[g, h] -= 1000;
                            }
                            if (i + j < Y)
                            {
                                if (i + j - ToWin + 1 >= 0)
                                {
                                    YFrom = i + ToWin - 1;
                                    XFrom = j - ToWin + 1;
                                    YTo = i;
                                    XTo = j;
                                    while (YFrom >= Y || XFrom < 0)
                                    {
                                        YFrom--;
                                        XFrom++;
                                    }
                                    while (YTo < Y - NewY || XTo >= NewX)
                                    {
                                        YTo++;
                                        XTo--;
                                    }
                                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                        SecondAlachsonArr[g - Y + NewY, h] -= 1000;
                                }
                            }
                            else
                            {
                                if (i + j - Y + ToWin <= Y)
                                {
                                    YFrom = i + ToWin - 1;
                                    XFrom = j - ToWin + 1;
                                    YTo = i;
                                    XTo = j;
                                    while (YFrom >= Y || XFrom < 0)
                                    {
                                        YFrom--;
                                        XFrom++;
                                    }
                                    while (YTo < Y - NewY || XTo >= NewX)
                                    {
                                        YTo++;
                                        XTo--;
                                    }
                                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                        SecondAlachsonArr[g - Y + NewY, h] -= 1000;
                                }
                            }
                        }
                    }
                }
            }
            while (btnArr[BestShura, BestAmuda].Text == "O" || btnArr[BestShura, BestAmuda].Text == "X")
            {
                if (BestShura < Y-1)
                    BestShura++;
                else
                {
                    BestShura = 0;
                    BestAmuda++;
                }
            }
            btnArr[BestShura, BestAmuda].Text = "O";
            YFrom = BestShura - ToWin + 1;
            YTo = BestShura;
            if (YFrom < 0)
                YFrom = 0;
            if (YTo > NewY - 1)
                YTo = NewY - 1;
            XFrom = BestAmuda - ToWin + 1;
            XTo = BestAmuda;
            if (XFrom < 0)
                XFrom = 0;
            if (XTo > NewX - 1)
                XTo = NewX - 1;
            for (int g = YFrom; g <= YTo; g++)
                ShuraArr[g, BestAmuda] += 1000;
            for (int g = XFrom; g <= XTo; g++)
                AmudaArr[BestShura, g] += 1000;
            if (BestShura > BestAmuda)
            {
                if (BestAmuda + 1 < ToWin)
                    YFrom = BestShura - BestAmuda;
                if (YFrom < 0)
                    YFrom = 0;
                if (BestShura - BestAmuda + ToWin <= Y)
                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                        MainAlachsonArr[g, h] += 1000;
            }
            else
            {
                if (BestShura + 1 < ToWin)
                    XFrom = BestAmuda - BestShura;
                if (YFrom < 0)
                    YFrom = 0;
                if (BestAmuda - BestShura + ToWin <= X)
                    for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                        MainAlachsonArr[g, h] += 1000;
            }
            XFrom = BestAmuda - ToWin + 1;
            if (XFrom < 0)
                XFrom = 0;
            YFrom = BestShura + ToWin;
            YTo = BestShura - ToWin + 1;
            if (YTo < Y - NewY)
                YTo = Y - NewY;
            if (BestShura + BestAmuda < Y)
            {
                if (BestShura + BestAmuda - ToWin + 1 >= 0)
                {
                    YFrom = BestShura + ToWin - 1;
                    XFrom = BestAmuda - ToWin + 1;
                    YTo = BestShura;
                    XTo = BestAmuda;
                    while (YFrom >= Y || XFrom < 0)
                    {
                        YFrom--;
                        XFrom++;
                    }
                    while (YTo < Y - NewY || XTo >= NewX)
                    {
                        YTo++;
                        XTo--;
                    }
                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                        SecondAlachsonArr[g - Y + NewY, h] += 1000;
                }
            }
            else
            {
                if (BestShura + BestAmuda - Y + ToWin <= Y)
                {
                    YFrom = BestShura + ToWin - 1;
                    XFrom = BestAmuda - ToWin + 1;
                    YTo = BestShura;
                    XTo = BestAmuda;
                    while (YFrom >= Y || XFrom < 0)
                    {
                        YFrom--;
                        XFrom++;
                    }
                    while (YTo < Y - NewY || XTo >= NewX)
                    {
                        YTo++;
                        XTo--;
                    }
                    for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                        SecondAlachsonArr[g - Y + NewY, h] += 1000;
                }
            }
            btnArr[BestShura, BestAmuda].ForeColor = Color.WhiteSmoke;
            btnArr[BestShura, BestAmuda].BackColor = Color.FromArgb(255, 30, 30, 40);
            counter--;
            string ComWinTemp = Win(BestShura, BestAmuda, false);
            if (ComWinTemp == "Win")
            {
                MessageBox.Show("המחשב ניצח");
                disableBoard();
            }
            if (ComWinTemp == "Draw")
            {
                MessageBox.Show("תיקו");
                disableBoard();
            }
        }
        /**
         .פונקציה זו נקראת כאשר השחקן לוחץ על אחד מהכפתורים שעל הלוח כאשר המשחק הוא בין השחקן למחשב
         היא אחראית על לסמן את המקום שהשחקן בחר במידה והוא בחר מקום פנוי
         ועל לבדוק האם מהלך זה הביא לניצחון
         .שתבצע את המהלך הבא של המחשב FirstComBestMove ובמידה ולא לקרוא לפונקציה 
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void ButtonArrayClickComp(object sender, EventArgs e)
        {
            int num, shura, amuda;
            string s = ((Button)(sender)).Text;
            if (s != "X" & s != "O")
            {
                counter--;
                num = int.Parse(s);
                shura = num / 1000;
                amuda = num % 1000;
                btnArr[shura, amuda].Text = "X";
                btnArr[shura, amuda].ForeColor = Color.Black;
                btnArr[shura, amuda].BackColor = Color.FromArgb(255, 225, 225, 205);
                YFrom = shura - ToWin + 1;
                YTo = shura;
                if (YFrom < 0)
                    YFrom = 0;
                if (YTo > NewY - 1)
                    YTo = NewY - 1;
                XFrom = amuda - ToWin + 1;
                XTo = amuda;
                if (XFrom < 0)
                    XFrom = 0;
                if (XTo > NewX - 1)
                    XTo = NewX - 1;
                for (int g = YFrom; g <= YTo; g++)
                    ShuraArr[g, amuda]++;
                for (int g = XFrom; g <= XTo; g++)
                    AmudaArr[shura, g]++;
                if (shura > amuda)
                {
                    if (amuda + 1 < ToWin)
                        YFrom = shura - amuda;
                    if (YFrom < 0)
                        YFrom = 0;
                    if (shura - amuda + ToWin <= Y)
                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                            MainAlachsonArr[g, h]++;
                }
                else
                {
                    if (shura + 1 < ToWin)
                        XFrom = amuda - shura;
                    if (YFrom < 0)
                        YFrom = 0;
                    if (amuda - shura + ToWin <= X)
                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                            MainAlachsonArr[g, h]++;
                }
                XFrom = amuda - ToWin + 1;
                if (XFrom < 0)
                    XFrom = 0;
                YFrom = shura + ToWin;
                YTo = shura - ToWin + 1;
                if (YTo < Y - NewY)
                    YTo = Y - NewY;
                if (shura + amuda < Y)
                {
                    if (shura + amuda - ToWin + 1 >= 0)
                    {
                        YFrom = shura + ToWin - 1;
                        XFrom = amuda - ToWin + 1;
                        YTo = shura;
                        XTo = amuda;
                        while (YFrom >= Y || XFrom < 0)
                        {
                            YFrom--;
                            XFrom++;
                        }
                        while (YTo < Y - NewY || XTo >= NewX)
                        {
                            YTo++;
                            XTo--;
                        }
                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                            SecondAlachsonArr[g - Y + NewY, h]++;
                    }
                }
                else
                {
                    if (shura + amuda - Y + ToWin <= Y)
                    {
                        YFrom = shura + ToWin - 1;
                        XFrom = amuda - ToWin + 1;
                        YTo = shura;
                        XTo = amuda;
                        while (YFrom >= Y || XFrom < 0)
                        {
                            YFrom--;
                            XFrom++;
                        }
                        while (YTo < Y - NewY || XTo >= NewX)
                        {
                            YTo++;
                            XTo--;
                        }
                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                            SecondAlachsonArr[g - Y + NewY, h]++;
                    }
                }
                string WinTemp = Win(shura, amuda, true);
                if (WinTemp == "Lose")
                {
                    if (StepsForwad > counter)
                    {
                        StepsForwad = counter;
                    }
                    FirstComBestMove(btnArr, StepsForwad);
                }
                else
                {
                    if (WinTemp == "Win")
                    {
                        MessageBox.Show(PlayerX + " ניצח ");
                        disableBoard();
                    }
                    else
                    {
                        MessageBox.Show("תיקו");
                        disableBoard();
                    }
                }
            }
        }
        /**
         .פונקציה זו נקראת כאשר השחקן לוחץ על אחד מהכפתורים שעל הלוח כאשר המשחק הוא בין שני שחקנים
         .היא אחראית על לסמן את הכפתור שעליו לחצנו, ולהחליט האם לסמן שמה איקס או עיגול על פי תור מי זה
         .בנוסף היא אחראית על להודיע לנו כאשר יש תיקו או ניצחון
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void ButtonArrayClickPlayers(object sender, EventArgs e)
        {
            int num, shura, amuda;
            string s = ((Button)(sender)).Text;
            if (s != "X" & s != "O")
            {
                counter--;
                num = int.Parse(s);
                shura = num / 1000;
                amuda = num % 1000;
                if (PlayerXTurn == true)
                {
                    btnArr[shura, amuda].Text = "X";
                    btnArr[shura, amuda].ForeColor = Color.Black;
                    btnArr[shura, amuda].BackColor = Color.FromArgb(255, 225, 225, 205);
                    YFrom = shura - ToWin + 1;
                    YTo = shura;
                    if (YFrom < 0)
                        YFrom = 0;
                    if (YTo > NewY - 1)
                        YTo = NewY - 1;
                    XFrom = amuda - ToWin + 1;
                    XTo = amuda;
                    if (XFrom < 0)
                        XFrom = 0;
                    if (XTo > NewX - 1)
                        XTo = NewX - 1;
                    for (int g = YFrom; g <= YTo; g++)
                        ShuraArr[g, amuda]++;
                    for (int g = XFrom; g <= XTo; g++)
                        AmudaArr[shura, g]++;
                    if (shura > amuda)
                    {
                        if (amuda + 1 < ToWin)
                            YFrom = shura - amuda;
                        if (YFrom < 0)
                            YFrom = 0;
                        if (shura - amuda + ToWin <= Y)
                            for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                MainAlachsonArr[g, h]++;
                    }
                    else
                    {
                        if (shura + 1 < ToWin)
                            XFrom = amuda - shura;
                        if (YFrom < 0)
                            YFrom = 0;
                        if (amuda - shura + ToWin <= X)
                            for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                MainAlachsonArr[g, h]++;
                    }
                    XFrom = amuda - ToWin + 1;
                    if (XFrom < 0)
                        XFrom = 0;
                    YFrom = shura + ToWin;
                    YTo = shura - ToWin + 1;
                    if (YTo < Y - NewY)
                        YTo = Y - NewY;
                    if (shura + amuda < Y)
                    {
                        if (shura + amuda - ToWin + 1 >= 0)
                        {
                            YFrom = shura + ToWin - 1;
                            XFrom = amuda - ToWin + 1;
                            YTo = shura;
                            XTo = amuda;
                            while (YFrom >= Y || XFrom < 0)
                            {
                                YFrom--;
                                XFrom++;
                            }
                            while (YTo < Y - NewY || XTo >= NewX)
                            {
                                YTo++;
                                XTo--;
                            }
                            for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                SecondAlachsonArr[g - Y + NewY, h]++;
                        }
                    }
                    else
                    {
                        if (shura + amuda - Y + ToWin <= Y)
                        {
                            YFrom = shura + ToWin - 1;
                            XFrom = amuda - ToWin + 1;
                            YTo = shura;
                            XTo = amuda;
                            while (YFrom >= Y || XFrom < 0)
                            {
                                YFrom--;
                                XFrom++;
                            }
                            while (YTo < Y - NewY || XTo >= NewX)
                            {
                                YTo++;
                                XTo--;
                            }
                            for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                SecondAlachsonArr[g - Y + NewY, h]++;
                        }
                    }
                    string WinTemp = Win(shura, amuda, PlayerXTurn);
                    if (WinTemp == "Win")
                    {
                        MessageBox.Show(PlayerX + " ניצח ");
                        disableBoard();
                    }
                    else if (WinTemp == "Draw")
                    {
                        MessageBox.Show("תיקו");
                        disableBoard();
                    }
                }
                else
                {
                    btnArr[shura, amuda].Text = "O";
                    btnArr[shura, amuda].ForeColor = Color.WhiteSmoke;
                    btnArr[shura, amuda].BackColor = Color.FromArgb(255, 30, 30, 40);
                    YFrom = shura - ToWin + 1;
                    YTo = shura;
                    if (YFrom < 0)
                        YFrom = 0;
                    if (YTo > NewY - 1)
                        YTo = NewY - 1;
                    XFrom = amuda - ToWin + 1;
                    XTo = amuda;
                    if (XFrom < 0)
                        XFrom = 0;
                    if (XTo > NewX - 1)
                        XTo = NewX - 1;
                    for (int g = YFrom; g <= YTo; g++)
                        ShuraArr[g, amuda] += 1000;
                    for (int g = XFrom; g <= XTo; g++)
                        AmudaArr[shura, g] += 1000;
                    if (shura > amuda)
                    {
                        if (amuda + 1 < ToWin)
                            YFrom = shura - amuda;
                        if (YFrom < 0)
                            YFrom = 0;
                        if (shura - amuda + ToWin <= Y)
                            for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                MainAlachsonArr[g, h] += 1000;
                    }
                    else
                    {
                        if (shura + 1 < ToWin)
                            XFrom = amuda - shura;
                        if (YFrom < 0)
                            YFrom = 0;
                        if (amuda - shura + ToWin <= X)
                            for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                                MainAlachsonArr[g, h] += 1000;
                    }
                    XFrom = amuda - ToWin + 1;
                    if (XFrom < 0)
                        XFrom = 0;
                    YFrom = shura + ToWin;
                    YTo = shura - ToWin + 1;
                    if (YTo < Y - NewY)
                        YTo = Y - NewY;
                    if (shura + amuda < Y)
                    {
                        if (shura + amuda - ToWin + 1 >= 0)
                        {
                            YFrom = shura + ToWin - 1;
                            XFrom = amuda - ToWin + 1;
                            YTo = shura;
                            XTo = amuda;
                            while (YFrom >= Y || XFrom < 0)
                            {
                                YFrom--;
                                XFrom++;
                            }
                            while (YTo < Y - NewY || XTo >= NewX)
                            {
                                YTo++;
                                XTo--;
                            }
                            for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                SecondAlachsonArr[g - Y + NewY, h] += 1000;
                        }
                    }
                    else
                    {
                        if (shura + amuda - Y + ToWin <= Y)
                        {
                            YFrom = shura + ToWin - 1;
                            XFrom = amuda - ToWin + 1;
                            YTo = shura;
                            XTo = amuda;
                            while (YFrom >= Y || XFrom < 0)
                            {
                                YFrom--;
                                XFrom++;
                            }
                            while (YTo < Y - NewY || XTo >= NewX)
                            {
                                YTo++;
                                XTo--;
                            }
                            for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                                SecondAlachsonArr[g - Y + NewY, h] += 1000;
                        }
                    }
                    string WinTemp = Win(shura, amuda, PlayerXTurn);
                    if (WinTemp == "Win")
                    {
                        MessageBox.Show(PlayerO + " ניצח ");
                        disableBoard();
                    }
                    else if (WinTemp == "Draw")
                    {
                        MessageBox.Show("תיקו");
                        disableBoard();
                    }
                }
                PlayerXTurn = !PlayerXTurn;
            }
        }
        /**
         ,(פונקציה זו אחראית על בדיקה האם יש ניצחון כרגע לדמות שנבחרה כקלט(משתמש\שחקן
         .כתוצאה ממהלך מסוים שדמות זו ביצעה
         .ומחזירה משתנה האם מהלך זה הביא לניצחון, לתיקו או לכלום
         קלט:
            מספר שמעיד באיזה שורה התרחש המהלך
            מספר שמעיד באיזה טור התרחש המהלך
            משתנה בוליאני שקובע באם המהלך בוצע על ידי השחקן או המחשב
         פלט:
            :שמתאר את התוצאות של מהלך זה. יכול להכיל string
            "Win" - מהלך זה הביא לניצחון לדמות שעשתה אותו
            "Draw" -  מהלך זה הביא לתיקו
            "Lose" – לא באמת הפסד, מהלך זה לא גרם לכלום
         */
        private string Win(int Shura, int Amuda, bool isX) 
        {
            YFrom = Shura - ToWin + 1;
            YTo = Shura;
            if (YFrom < 0)
                YFrom = 0;
            if (YTo > NewY - 1)
                YTo = NewY - 1;
            XFrom = Amuda - ToWin + 1;
            XTo = Amuda;
            if (XFrom < 0)
                XFrom = 0;
            if (XTo > NewX - 1)
                XTo = NewX - 1;
            if (isX == true)
            {
                for (int g = YFrom; g <= YTo; g++)
                    if (ShuraArr[g, Amuda] / 1000 == 0 && ShuraArr[g, Amuda] % 1000 == ToWin)
                        return "Win";
                for (int g = XFrom; g <= XTo; g++)
                    if (AmudaArr[Shura, g] / 1000 == 0 && AmudaArr[Shura, g] % 1000 == ToWin)
                        return "Win";
                if (Shura > Amuda)
                {
                    if (Amuda + 1 < ToWin)
                        YFrom = Shura - Amuda;
                    if (YFrom < 0)
                        YFrom = 0;
                    if (Shura - Amuda + ToWin <= Y)
                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                            if (MainAlachsonArr[g, h] / 1000 == 0 && MainAlachsonArr[g, h] % 1000 == ToWin)
                                return "Win";
                }
                else
                {
                    if (Shura + 1 < ToWin)
                        XFrom = Amuda - Shura;
                    if (YFrom < 0)
                        YFrom = 0;
                    if (Amuda - Shura + ToWin <= X)
                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                            if (MainAlachsonArr[g, h] / 1000 == 0 && MainAlachsonArr[g, h] % 1000 == ToWin)
                                return "Win";
                }
                if (Shura + Amuda < Y)
                {
                    if (Shura + Amuda - ToWin + 1 >= 0)
                    {
                        YFrom = Shura + ToWin - 1;
                        XFrom = Amuda - ToWin + 1;
                        YTo = Shura;
                        XTo = Amuda;
                        while (YFrom >= Y || XFrom < 0)
                        {
                            YFrom--;
                            XFrom++;
                        }
                        while (YTo < Y - NewY || XTo >= NewX)
                        {
                            YTo++;
                            XTo--;
                        }
                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                            if (SecondAlachsonArr[g - Y + NewY, h] / 1000 == 0 && SecondAlachsonArr[g - Y + NewY, h] % 1000 == ToWin)
                                return "Win";
                    }
                }
                else
                {
                    if (Shura + Amuda - Y + ToWin <= Y)
                    {
                        YFrom = Shura + ToWin - 1;
                        XFrom = Amuda - ToWin + 1;
                        YTo = Shura;
                        XTo = Amuda;
                        while (YFrom >= Y || XFrom < 0)
                        {
                            YFrom--;
                            XFrom++;
                        }
                        while (YTo < Y - NewY || XTo >= NewX)
                        {
                            YTo++;
                            XTo--;
                        }
                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                            if (SecondAlachsonArr[g - Y + NewY, h] / 1000 == 0 && SecondAlachsonArr[g - Y + NewY, h] % 1000 == ToWin)
                                return "Win";
                    }
                }
            }
            else
            {
                for (int g = YFrom; g <= YTo; g++)
                    if (ShuraArr[g, Amuda] % 1000 == 0 && ShuraArr[g, Amuda] / 1000 == ToWin)
                        return "Win";
                for (int g = XFrom; g <= XTo; g++)
                    if (AmudaArr[Shura, g] % 1000 == 0 && AmudaArr[Shura, g] / 1000 == ToWin)
                        return "Win";
                if (Shura > Amuda)
                {
                    if (Amuda + 1 < ToWin)
                        YFrom = Shura - Amuda;
                    if (YFrom < 0)
                        YFrom = 0;
                    if (Shura - Amuda + ToWin <= Y)
                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                            if (MainAlachsonArr[g, h] % 1000 == 0 && MainAlachsonArr[g, h] / 1000 == ToWin)
                                return "Win";
                }
                else
                {
                    if (Shura + 1 < ToWin)
                        XFrom = Amuda - Shura;
                    if (YFrom < 0)
                        YFrom = 0;
                    if (Amuda - Shura + ToWin <= X)
                        for (int g = YFrom, h = XFrom; g <= YTo && h <= XTo; g++, h++)
                            if (MainAlachsonArr[g, h] % 1000 == 0 && MainAlachsonArr[g, h] / 1000 == ToWin)
                                return "Win";
                }
                if (Shura + Amuda < Y)
                {
                    if (Shura + Amuda - ToWin + 1 >= 0)
                    {
                        YFrom = Shura + ToWin - 1;
                        XFrom = Amuda - ToWin + 1;
                        YTo = Shura;
                        XTo = Amuda;
                        while (YFrom >= Y || XFrom < 0)
                        {
                            YFrom--;
                            XFrom++;
                        }
                        while (YTo < Y - NewY || XTo >= NewX)
                        {
                            YTo++;
                            XTo--;
                        }
                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                            if (SecondAlachsonArr[g - Y + NewY, h] % 1000 == 0 && SecondAlachsonArr[g - Y + NewY, h] / 1000 == ToWin)
                                return "Win";
                    }
                }
                else
                {
                    if (Shura + Amuda - Y + ToWin <= Y)
                    {
                        YFrom = Shura + ToWin - 1;
                        XFrom = Amuda - ToWin + 1;
                        YTo = Shura;
                        XTo = Amuda;
                        while (YFrom >= Y || XFrom < 0)
                        {
                            YFrom--;
                            XFrom++;
                        }
                        while (YTo < Y - NewY || XTo >= NewX)
                        {
                            YTo++;
                            XTo--;
                        }
                        for (int g = YFrom, h = XFrom; g >= YTo && h <= XTo; g--, h++)
                            if (SecondAlachsonArr[g - Y + NewY, h] % 1000 == 0 && SecondAlachsonArr[g - Y + NewY, h] / 1000 == ToWin)
                                return "Win";
                    }
                }
            }
            if (counter == 0)
                return "Draw";
            return "Lose";
        }
        /**
         .הפונקציה נקראת כאשר השחקן לחץ על הכפתור להתחלת המשחק
         ,היא אחראית על נתינת ערכים למשתנים החשובים בתוכנית אשר השחקן מזין
         .על בדיקה שערכים אלו תקניים ועל יצירת לוח המשחק
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void btn_StartGame_Click(object sender, EventArgs e)
        {
            panel1.Enabled = true;
            panel1.Controls.Clear();
            PlayerXTurn = true;
            Y = 3;
            X = 3;
            ToWin = 3;
            StepsForwad = 3;
            try
            {
                Y = int.Parse(txtbox_Y.Text);
            }
            catch { }
            try
            {
                X = int.Parse(txtbox_X.Text);
            }
            catch { }
            try
            {
                ToWin = int.Parse(txtbox_ToWin.Text);
            }
            catch { }
            try
            {
                StepsForwad = int.Parse(txtbox_StepsForwad.Text);
            }
            catch { }
            if (X < 1)
            {
                MessageBox.Show("לא תקין X ערך");
                X = 3;
                txtbox_X.Text = "3";
            }
            if (Y < 1)
            {
                MessageBox.Show("לא תקין Y ערך");
                Y = 3;
                txtbox_Y.Text = "3";
            }
            if (ToWin > Y || ToWin > X || ToWin<1)
            {
                if (Y > X)
                    ToWin = X;
                else
                    ToWin = Y;
                txtbox_ToWin.Text = ToWin.ToString();
            }
            if (StepsForwad < 1)
            {
                MessageBox.Show(" ערך רמת קושי לא תקין");
                StepsForwad = 3;
                txtbox_StepsForwad.Text = "3";
            }
            if (txtbox_PlayerX.Text != "")
                PlayerX = txtbox_PlayerX.Text;
            else
            {
                if (chkbox_vsComp.Checked == true)
                    PlayerX = "השחקן";
                else
                    PlayerX = "איקס";
            }
            if (txtbox_PlayerO.Text != "")
                PlayerO = txtbox_PlayerO.Text;
            else
                PlayerO = "עיגול";
            btnArr = new Button[Y, X];
            int h = panel1.Height / Y;
            int w = panel1.Width / X;
            NewY = Y - ToWin + 1;
            NewX = X - ToWin + 1;
            ShuraArr = new int[NewY, X];
            AmudaArr = new int[Y, NewX];
            MainAlachsonArr = new int[NewY, NewX];
            SecondAlachsonArr = new int[NewY, NewX];
            for (int i = 0; i < NewY; i++)
            {
                for (int j = 0; j < X; j++)
                {
                    ShuraArr[i, j] = 0;
                }
            }
            for (int i = 0; i < Y; i++)
            {
                for (int j = 0; j < NewX; j++)
                {
                    AmudaArr[i, j] = 0;
                }
            }
            for (int i = 0; i < NewY; i++)
            {
                for (int j = 0; j < NewX; j++)
                {
                    MainAlachsonArr[i, j] = 0;
                    SecondAlachsonArr[i, j] = 0;
                }
            }
            for (int i = 0; i < Y; i++)
            {
                for (int j = 0; j < X; j++)
                {
                    btnArr[i, j] = new Button();
                    btnArr[i, j].Height = h;
                    btnArr[i, j].Width = w;
                    if (h < w)
                        btnArr[i, j].Font = new Font(btnArr[i, j].Font.FontFamily, (int)(h / 1.4 - 5));
                    else
                        btnArr[i, j].Font = new Font(btnArr[i, j].Font.FontFamily,(int)(w / 1.4 - 5));
                    btnArr[i, j].Top = h * i;
                    btnArr[i, j].Left = w * j;
                    btnArr[i, j].BackColor = Color.FromArgb(255, 120, 180, 180);
                    panel1.Controls.Add(btnArr[i, j]);
                    if (chkbox_vsComp.Checked == true)
                    {
                        btnArr[i, j].Click += new EventHandler(ButtonArrayClickComp);
                    }
                    else
                    {
                        btnArr[i, j].Click += new EventHandler(ButtonArrayClickPlayers);
                    }
                    btnArr[i, j].ForeColor = Color.FromArgb(255, 120, 180, 180);
                    btnArr[i, j].Text = (i * 1000 + j).ToString();
                }
            }
            counter = Y * X;
            if (chkbox_CompFirst.Checked == true)
                FirstComBestMove(btnArr, StepsForwad);
        }
        /**
         ,פונקציה זו נקראת על ידי פונקציות אחרות במצב של ניצחון או תיקו
         ,והיא אחראית על מחיקת טקסט זמני מהכפתורים במידה והיה עליהם טקסט זמני
         .ועל נטרול הלוח כדי שאי יהיה אפשר להמשיך ללחוץ על הכפתורים שהוא מכיל עד שיתחיל משחק חדש
         קלט:
            אין
         פלט:
            אין
         */
        private void disableBoard()
        {
            for (int i = 0; i < Y; i++)
            {
                for(int j = 0; j < X; j++)
                {
                    try
                    {
                        int temp = int.Parse(btnArr[i, j].Text);
                        btnArr[i, j].Text = "";
                    }
                    catch
                    {
                    } 
                }
            }
            panel1.Enabled = false;
        }
        /**
         הפונקציה הזו נקראת כאשר עולה התוכנית
         היא אחראית שעם עליית התוכנית סימון ברירת המחדל יהיה שההמשחק הוא נגד המחשב
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void XO_Load(object sender, EventArgs e)
        {
            chkbox_vsComp.Checked = true;
        }
        /**
         ":O פונקציה זו אחראית על לאפשר או לנטרל אפשרות לכתוב בתיבה שרשום לידה "שם שחקן 
         על לנטרל או לאפשר לסמן את התיבה של האם המחשב מתחיל, ולנטרל או לאפשר לבחור כמה צעדים קדימה המחשב יחשוב
         היא בוחרת לעשות זאת לפי האם מדובר במשחק של שני שחקנים או נגד המחשב - כלומר על פי הסימון של התיבה שקשורה לנגד מי המשחק
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void chkbox_vsComp_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_vsComp.Checked == true)
            {
                txtbox_PlayerO.Enabled = false;
                txtbox_StepsForwad.Enabled = true;
                chkbox_CompFirst.Enabled = true;
            }
            else
            {
                txtbox_PlayerO.Enabled = true;
                txtbox_StepsForwad.Enabled = false;
                chkbox_CompFirst.Checked = false;
                chkbox_CompFirst.Enabled = false;
            }
        }
    }
}
